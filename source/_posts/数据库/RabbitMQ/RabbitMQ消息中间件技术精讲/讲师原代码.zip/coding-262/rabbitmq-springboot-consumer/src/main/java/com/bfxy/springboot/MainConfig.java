package com.bfxy.springboot;

import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.annotation.Configuration;

@Configuration
@ComponentScan({"com.bfxy.springboot.*"})
public class MainConfig {

}
